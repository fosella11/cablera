# Android-Example-HLS-ExoPlayer
Just example only HLS format streaming using ExoPlayer
