package com.Domingame.cablera;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by fede on 03/11/17.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void onSampleSelected(ListSamples.ListSamp listSamp) {
        Intent mpdIntent = new Intent(this, PlayerActivity.class)
                .setData(Uri.parse(listSamp.uri))
                .putExtra(PlayerActivity.CONTENT_ID_EXTRA, listSamp.contentId)
                .putExtra(PlayerActivity.CONTENT_TYPE_EXTRA, listSamp.type)
                .putExtra(PlayerActivity.PROVIDER_EXTRA, listSamp.provider);
        startActivity(mpdIntent);
    }

    public void onClick1(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[0]);
    }

    public void onClick2(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[1]);
    }

    public void onClick3(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[2]);
    }

    public void onClick4(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[3]);
    }

    public void onClick5(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[5]);
    }

    public void onClick6(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[6]);
    }

    public void onClick7(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[7]);
    }

    public void onClick8(View view) {
        onSampleSelected(com.Domingame.cablera.ListSamples.HLS[8]);
    }
}
