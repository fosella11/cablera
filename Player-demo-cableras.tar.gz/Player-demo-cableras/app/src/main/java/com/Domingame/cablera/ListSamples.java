package com.Domingame.cablera;

import com.google.android.exoplayer.util.Util;

import java.util.Locale;

/**
 * Created by fede on 03/11/17.
 */

class ListSamples {

  public static class ListSamp {

    public final String name;
    public final String contentId;
    public final String provider;
    public final String uri;
    public final int type;

    public ListSamp(String name, String uri, int type) {
      this(name, name.toLowerCase(Locale.US).replaceAll("\\s", ""), "", uri, type);
    }

    public ListSamp(String name, String contentId, String provider, String uri, int type) {
      this.name = name;
      this.contentId = contentId;
      this.provider = provider;
      this.uri = uri;
      this.type = type;
    }

  }

  public static final ListSamp[] HLS = new ListSamp[] {
    new ListSamp("CANAL1", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL2", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL3", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL4", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL5", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL6", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL7", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL8", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),
    new ListSamp("CANAL9", "http://ayacucho.dnsalias.com:6081/hls/space/index.m3u8", Util.TYPE_HLS),

  };

  private ListSamples() {}

}
